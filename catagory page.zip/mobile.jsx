/* Mobile variants — single component file with all 3 mobile screens */

const MobileFrame = ({ children }) => (
  <div className="mb-artboard" style={{ width: "100%", minHeight: "100%", background: "#fff" }}>
    {/* iOS-style status bar */}
    <div style={{
      height: 44, padding: "0 18px",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      fontSize: 13, fontWeight: 600, color: "var(--mb-navy)",
      background: "#fff",
    }}>
      <span>9:41</span>
      <span style={{ display: "flex", gap: 5, alignItems: "center" }}>
        <span style={{ display: "inline-block", width: 16, height: 9, border: "1px solid currentColor", borderRadius: 2, position: "relative" }}>
          <span style={{ position: "absolute", inset: 1, background: "currentColor", width: "75%", borderRadius: 1 }} />
        </span>
      </span>
    </div>
    {/* Compact app header */}
    <div style={{
      padding: "8px 16px 12px",
      display: "flex", alignItems: "center", gap: 12,
      borderBottom: "1px solid var(--mb-line)",
    }}>
      <Icon name="menu" size={22} color="var(--mb-navy)" />
      <div style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 700, color: "var(--mb-navy)" }}>
        E-Mart<span style={{ color: "var(--mb-pink)" }}>.</span>
      </div>
      <div style={{
        flex: 1, height: 34, borderRadius: 999,
        background: "var(--mb-cream)", border: "1px solid var(--mb-line)",
        display: "flex", alignItems: "center", padding: "0 12px", gap: 6,
        color: "var(--mb-ink-3)", fontSize: 12,
      }}>
        <Icon name="search" size={14} />
        <span>Search</span>
      </div>
      <Icon name="bag" size={20} color="var(--mb-navy)" />
    </div>
    {children}
    {/* Bottom tab bar */}
    <div style={{
      position: "sticky", bottom: 0,
      borderTop: "1px solid var(--mb-line)",
      background: "#fff",
      display: "grid", gridTemplateColumns: "repeat(5, 1fr)",
      padding: "8px 0 14px",
    }}>
      {[
        ["search","Browse",false],
        ["sparkle","Quiz",false],
        ["heart","Wishlist",false],
        ["bag","Cart",false],
        ["user","Me",false],
      ].map(([i, l], idx) => (
        <div key={l} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, color: idx === 0 ? "var(--mb-pink)" : "var(--mb-ink-3)" }}>
          <Icon name={i} size={20} />
          <span style={{ fontSize: 10 }}>{l}</span>
        </div>
      ))}
    </div>
  </div>
);

/* MOBILE — Direction A: Editorial */
const DirectionA_Mobile = () => (
  <MobileFrame>
    <div style={{ padding: "16px 16px 6px", background: "linear-gradient(180deg, var(--mb-cream), #fff)" }}>
      <div className="mb-eyebrow">— Issue 04 · Spring Edit</div>
      <h1 className="mb-h-display" style={{ fontSize: 34, lineHeight: 1.05, margin: "8px 0 10px", color: "var(--mb-navy)" }}>
        The <em style={{ color: "var(--mb-pink)" }}>Beauty</em> Atlas of Bangladesh.
      </h1>
      <p style={{ fontSize: 13, color: "var(--mb-ink-2)", margin: "0 0 14px", lineHeight: 1.5 }}>
        12,000+ products. 250 brands. Curated by editors, ranked by you.
      </p>
      <button className="mb-btn mb-btn-dark" style={{ width: "100%" }}>
        <Icon name="sparkle" size={14} color="#D4A248" /> Take the Skin Quiz
      </button>
    </div>

    {/* Category chips */}
    <div style={{ display: "flex", gap: 6, padding: "14px 16px", overflowX: "auto" }} className="mb-noscroll">
      {["All","Popular","Skincare","Makeup","Hair","Fragrance","Body","Wellness"].map((c, i) => (
        <span key={c} className="mb-chip" data-active={i === 0 ? "true" : "false"}>{c}</span>
      ))}
    </div>

    {/* Hero magazine card */}
    <div style={{ padding: "0 16px" }}>
      <div style={{ position: "relative", borderRadius: "var(--mb-radius-lg)", overflow: "hidden", aspectRatio: "4/5" }}>
        <div className="mb-img-placeholder pink" style={{ position: "absolute", inset: 0 }}>editorial · skincare</div>
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent 35%, rgba(27,27,47,.85))" }} />
        <div style={{ position: "absolute", left: 16, right: 16, bottom: 16, color: "#fff" }}>
          <span className="mb-badge" style={{ background: "rgba(255,255,255,.18)", color: "#fff", backdropFilter: "blur(8px)" }}>01 / 06</span>
          <div className="mb-bn" style={{ fontSize: 11, color: "var(--mb-gold-soft)", marginTop: 8, letterSpacing: ".15em", textTransform: "uppercase" }}>ত্বক</div>
          <div className="mb-h-display" style={{ fontSize: 30, lineHeight: 1, marginTop: 4 }}>Skincare</div>
          <div style={{ fontSize: 12, opacity: .85, marginTop: 6 }}>Glass-skin routines · 2,840 products</div>
        </div>
      </div>
    </div>

    {/* Smaller cards */}
    <div style={{ padding: "12px 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      {[
        ["Makeup","মেকআপ","1,620","gold"],
        ["Fragrance","সুগন্ধি","480","navy"],
        ["Hair","চুল","920","pink"],
        ["Body","শরীর","760","gold"],
      ].map(([n, bn, p, c], i) => (
        <div key={i} style={{ borderRadius: "var(--mb-radius)", overflow: "hidden", border: "1px solid var(--mb-line)", background: "#fff" }}>
          <div className={`mb-img-placeholder ${c}`} style={{ aspectRatio: "1" }}>{n.toLowerCase()}</div>
          <div style={{ padding: 10 }}>
            <div className="mb-bn" style={{ fontSize: 10, color: "var(--mb-ink-3)" }}>{bn}</div>
            <div style={{ fontSize: 13.5, fontWeight: 500, color: "var(--mb-navy)", marginTop: 1 }}>{n}</div>
            <div style={{ fontSize: 10.5, color: "var(--mb-ink-3)", marginTop: 2 }}>{p} products</div>
          </div>
        </div>
      ))}
    </div>

    {/* Editor's picks */}
    <div style={{ padding: "20px 16px", background: "var(--mb-cream)" }}>
      <div className="mb-eyebrow">— Editor's picks</div>
      <h2 className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-navy)", margin: "4px 0 12px" }}>This month's loved.</h2>
      <div style={{ display: "flex", gap: 10, overflowX: "auto" }} className="mb-noscroll">
        {[1,2,3].map((i) => (
          <div key={i} style={{ minWidth: 160, background: "#fff", borderRadius: 12, padding: 10, border: "1px solid var(--mb-line)" }}>
            <div className={`mb-img-placeholder ${["pink","gold","navy"][i-1]}`} style={{ aspectRatio: "1", borderRadius: 8, marginBottom: 8 }}>product</div>
            <div style={{ fontSize: 9.5, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>LUMIÈRE</div>
            <div style={{ fontSize: 12.5, fontWeight: 500 }}>Hydra Glow Serum</div>
            <div style={{ fontSize: 12.5, color: "var(--mb-pink)", fontWeight: 600, marginTop: 4 }}>৳1,490</div>
          </div>
        ))}
      </div>
    </div>

    {/* Skin concerns */}
    <div style={{ padding: "20px 16px" }}>
      <div className="mb-eyebrow mb-eyebrow-gold">— Skin goals</div>
      <h2 className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-navy)", margin: "4px 0 12px" }}>Tell us your concern.</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {[["Acne","485","pink"],["Dullness","290","gold"],["Pores","300","pink"],["Sensitivity","220","navy"]].map(([n, p, c], i) => (
          <div key={i} style={{ borderRadius: 12, border: "1px solid var(--mb-line)", overflow: "hidden", background: "#fff", display: "flex", alignItems: "center", gap: 10, padding: 8 }}>
            <div className={`mb-img-placeholder ${c}`} style={{ width: 44, height: 44, borderRadius: 8 }}> </div>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>{n}</div>
              <div style={{ fontSize: 10.5, color: "var(--mb-ink-3)" }}>{p} products</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </MobileFrame>
);

/* MOBILE — Direction B: Live Pulse */
const DirectionB_Mobile = () => (
  <MobileFrame>
    {/* Live ticker */}
    <div style={{ background: "var(--mb-navy)", color: "#fff", padding: "8px 14px", fontSize: 11, display: "flex", alignItems: "center", gap: 8 }}>
      <span className="mb-badge mb-badge-live" style={{ background: "rgba(217,83,79,.2)", color: "#FFB4B0" }}>LIVE</span>
      <span style={{ flex: 1 }}><strong>2,847</strong> shopping now · <strong style={{ color: "var(--mb-gold)" }}>02:14:38</strong> left</span>
    </div>

    {/* Hero */}
    <div style={{ background: "linear-gradient(135deg, var(--mb-navy) 0%, #2a2a4a 100%)", color: "#fff", padding: "20px 16px" }}>
      <span className="mb-badge" style={{ background: "rgba(232,115,158,.2)", color: "var(--mb-pink-soft)" }}>✦ FLASH WEEK · DAY 3</span>
      <h1 className="mb-h-display" style={{ fontSize: 32, lineHeight: 1.08, margin: "10px 0" }}>
        Up to <span style={{ color: "var(--mb-gold)" }}>50% off</span> across all categories.
      </h1>
      <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
        {[["02","HR"],["14","MN"],["38","SC"]].map(([n, l]) => (
          <div key={l} style={{ flex: 1, background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.12)", borderRadius: 10, padding: "8px 0", textAlign: "center" }}>
            <div className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-gold)" }}>{n}</div>
            <div style={{ fontSize: 9, opacity: .6, letterSpacing: ".15em" }}>{l}</div>
          </div>
        ))}
      </div>
      <button className="mb-btn mb-btn-primary" style={{ width: "100%", marginTop: 12 }}>Shop the deals <Icon name="arrow-right" size={14} /></button>
    </div>

    {/* Trending leaderboard */}
    <div style={{ padding: "16px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <h2 className="mb-h-display" style={{ fontSize: 20, color: "var(--mb-navy)", margin: 0 }}>Trending right now</h2>
        <span className="mb-badge mb-badge-live">LIVE</span>
      </div>
      {[
        { r: 1, n: "Niacinamide 10% Serum", b: "Lumière BD", v: "+312%", left: 14 },
        { r: 2, n: "Velvet Matte Lipstick", b: "Noor Studio", v: "+248%", left: 47 },
        { r: 3, n: "Argan Hair Oil 100ml", b: "Shaba Co.", v: "+196%", left: 8 },
      ].map(p => (
        <div key={p.r} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: "1px solid var(--mb-line)" }}>
          <span className="mb-h-display" style={{ fontSize: 18, color: "var(--mb-gold)" }}>0{p.r}</span>
          <div className={`mb-img-placeholder ${["pink","gold","navy"][p.r-1]}`} style={{ width: 44, height: 44, borderRadius: 8 }}>·</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>{p.n}</div>
            <div style={{ fontSize: 10.5, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>{p.b}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11.5, color: "var(--mb-success)", fontWeight: 600 }}>{p.v}</div>
            <div style={{ fontSize: 10, color: p.left < 15 ? "var(--mb-danger)" : "var(--mb-ink-3)" }}>{p.left} left</div>
          </div>
        </div>
      ))}
    </div>

    {/* Popular categories with trend bars */}
    <div style={{ padding: "0 16px 16px" }}>
      <h2 className="mb-h-display" style={{ fontSize: 20, color: "var(--mb-navy)", margin: "8px 0 10px" }}>What BD is shopping</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {[
          { n: "Sunscreen", a: "SPF", trend: 38, color: "gold", live: 124 },
          { n: "Serum", a: "SA", trend: 72, color: "pink", live: 312, hot: true },
          { n: "Lipstick", a: "L", trend: 24, color: "pink", live: 88 },
          { n: "Perfume", a: "P", trend: 51, color: "navy", live: 142 },
        ].map((c, i) => (
          <div key={i} style={{ background: "#fff", border: "1px solid var(--mb-line)", borderRadius: 12, padding: 12, position: "relative" }}>
            {c.hot && <span style={{ position: "absolute", top: 8, right: 8, fontSize: 9, fontWeight: 700, color: "var(--mb-danger)" }}>🔥 HOT</span>}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <div className={`mb-img-placeholder ${c.color}`} style={{ width: 32, height: 32, borderRadius: 999, fontSize: 11, fontWeight: 600 }}>{c.a}</div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{c.n}</div>
            </div>
            <div style={{ height: 3, background: "var(--mb-cream)", borderRadius: 999, overflow: "hidden", marginBottom: 5 }}>
              <div style={{ width: `${c.trend}%`, height: "100%", background: "linear-gradient(90deg, var(--mb-pink), var(--mb-gold))" }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10 }}>
              <span style={{ color: "var(--mb-success)", fontWeight: 600 }}>↑ {c.trend}%</span>
              <span style={{ color: "var(--mb-ink-3)" }}>{c.live} viewing</span>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Flash deals */}
    <div style={{ padding: "16px", background: "linear-gradient(180deg, var(--mb-pink-bg), #fff)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <h2 className="mb-h-display" style={{ fontSize: 20, color: "var(--mb-navy)", margin: 0 }}>🔥 Flash deals</h2>
        <span style={{ fontSize: 11, color: "var(--mb-ink-2)" }}>02:14:38 left</span>
      </div>
      <div style={{ display: "flex", gap: 10, overflowX: "auto" }} className="mb-noscroll">
        {[
          { n: "Niacinamide", b: "Lumière", p: 749, o: 1490, sold: 87, color: "pink" },
          { n: "Matte Lipstick", b: "Noor", p: 425, o: 850, sold: 53, color: "gold" },
          { n: "Oud Attar", b: "Aroma", p: 1100, o: 2200, sold: 92, color: "navy" },
        ].map((p, i) => (
          <div key={i} style={{ minWidth: 140, background: "#fff", border: "1px solid var(--mb-line)", borderRadius: 12, padding: 10 }}>
            <div className={`mb-img-placeholder ${p.color}`} style={{ aspectRatio: "1", borderRadius: 8, position: "relative", marginBottom: 8 }}>
              <span className="mb-badge mb-badge-pink" style={{ position: "absolute", top: 6, left: 6, fontSize: 9 }}>−{Math.round((1-p.p/p.o)*100)}%</span>
            </div>
            <div style={{ fontSize: 9.5, color: "var(--mb-ink-3)", textTransform: "uppercase" }}>{p.b}</div>
            <div style={{ fontSize: 12, fontWeight: 500 }}>{p.n}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "var(--mb-pink)", marginTop: 4 }}>৳{p.p}</div>
            <div style={{ height: 4, background: "var(--mb-cream)", borderRadius: 999, marginTop: 6, overflow: "hidden" }}>
              <div style={{ width: `${p.sold}%`, height: "100%", background: p.sold > 80 ? "var(--mb-danger)" : "var(--mb-gold)" }} />
            </div>
            <div style={{ fontSize: 9.5, color: p.sold > 80 ? "var(--mb-danger)" : "var(--mb-ink-3)", marginTop: 3, fontWeight: 600 }}>{p.sold} sold</div>
          </div>
        ))}
      </div>
    </div>
  </MobileFrame>
);

/* MOBILE — Direction C: Quiz-first */
const DirectionC_Mobile = () => (
  <MobileFrame>
    <div style={{ padding: "20px 16px", background: "var(--mb-cream)" }}>
      <div className="mb-eyebrow">— Step 01 · Tell us about you</div>
      <h1 className="mb-h-display" style={{ fontSize: 30, lineHeight: 1.08, margin: "8px 0 10px", color: "var(--mb-navy)" }}>
        Skip the guesswork. Build your <em style={{ color: "var(--mb-pink)" }}>routine</em>.
      </h1>
      <p style={{ fontSize: 13, color: "var(--mb-ink-2)", margin: "0 0 14px", lineHeight: 1.5 }}>
        6 questions. Personalised results from 250 brands.
      </p>

      <div style={{ background: "#fff", border: "1px solid var(--mb-line)", borderRadius: 16, padding: 16, boxShadow: "var(--mb-shadow)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, fontSize: 10, letterSpacing: ".15em", color: "var(--mb-ink-3)" }}>
          <span>Q1 / 6</span>
          <div style={{ flex: 1, height: 3, background: "var(--mb-cream)", borderRadius: 999, margin: "0 10px", overflow: "hidden" }}>
            <div style={{ width: "16%", height: "100%", background: "var(--mb-pink)" }} />
          </div>
          <span>~60s</span>
        </div>
        <div className="mb-h-display" style={{ fontSize: 17, color: "var(--mb-navy)", marginBottom: 12 }}>Shopping for today?</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
          {[["Skincare","ত্বক"],["Makeup","মেকআপ"],["Hair","চুল"],["Fragrance","সুগন্ধি"],["Body","শরীর"],["Wellness","সুস্থতা"]].map(([n, bn], i) => (
            <button key={n} style={{
              padding: "10px",
              background: i === 0 ? "var(--mb-navy)" : "#fff",
              color: i === 0 ? "#fff" : "var(--mb-navy)",
              border: i === 0 ? "1px solid var(--mb-navy)" : "1px solid var(--mb-line)",
              borderRadius: 9,
              textAlign: "left",
              cursor: "pointer",
            }}>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>{n}</div>
              <div className="mb-bn" style={{ fontSize: 10, opacity: .65 }}>{bn}</div>
            </button>
          ))}
        </div>
        <button className="mb-btn mb-btn-primary" style={{ width: "100%", marginTop: 12, height: 38 }}>Next <Icon name="arrow-right" size={14} /></button>
      </div>

      <div style={{ textAlign: "center", marginTop: 12, fontSize: 12, color: "var(--mb-ink-3)" }}>
        Skip & browse all categories →
      </div>
    </div>

    {/* Six worlds */}
    <div style={{ padding: "20px 16px" }}>
      <div style={{ textAlign: "center", marginBottom: 14 }}>
        <div className="mb-eyebrow mb-eyebrow-gold">— Or browse straight in</div>
        <h2 className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-navy)", margin: "4px 0 0" }}>Six worlds. One trolley.</h2>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
        {[
          ["Skincare","ত্বক","pink"],["Makeup","মেকআপ","gold"],["Hair","চুল","pink"],
          ["Fragrance","সুগন্ধি","navy"],["Body","শরীর","gold"],["Wellness","সুস্থতা","pink"],
        ].map(([n, bn, c]) => (
          <div key={n} style={{ borderRadius: 12, overflow: "hidden", border: "1px solid var(--mb-line)", background: "#fff" }}>
            <div className={`mb-img-placeholder ${c}`} style={{ aspectRatio: "1" }}>{n.toLowerCase()}</div>
            <div style={{ padding: 8, textAlign: "center" }}>
              <div className="mb-bn" style={{ fontSize: 9.5, color: "var(--mb-ink-3)" }}>{bn}</div>
              <div style={{ fontSize: 12.5, fontWeight: 500, color: "var(--mb-navy)" }}>{n}</div>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Routine builder card */}
    <div style={{ padding: "20px 16px", background: "var(--mb-navy)", color: "#fff" }}>
      <span className="mb-badge" style={{ background: "rgba(212,162,72,.18)", color: "var(--mb-gold)" }}>✦ ROUTINE BUILDER</span>
      <h2 className="mb-h-display" style={{ fontSize: 22, lineHeight: 1.15, margin: "10px 0 8px" }}>Pick a concern. Get a routine.</h2>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginTop: 8 }}>
        {["Acne","Dullness","Pigmentation","Sensitive","Pores","Anti-Age"].map((x, i) => (
          <span key={x} style={{
            padding: "6px 12px", borderRadius: 999, fontSize: 11,
            background: i === 1 ? "var(--mb-pink)" : "rgba(255,255,255,.08)",
            border: i === 1 ? "1px solid var(--mb-pink)" : "1px solid rgba(255,255,255,.12)",
          }}>{x}</span>
        ))}
      </div>
      <div style={{ marginTop: 14, fontSize: 11, opacity: .6 }}>SHOWING ROUTINE FOR · DULLNESS</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 8 }}>
        {[
          { s: 1, n: "Gentle Foam", p: 480, color: "pink" },
          { s: 2, n: "Vit C Serum", p: 1490, color: "gold" },
          { s: 3, n: "Ceramide", p: 1180, color: "pink" },
          { s: 4, n: "SPF 50", p: 920, color: "gold" },
        ].map(p => (
          <div key={p.s} style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 10, padding: 10, position: "relative" }}>
            <span className="mb-h-display" style={{ position: "absolute", top: 6, right: 10, fontSize: 22, color: "rgba(212,162,72,.4)" }}>0{p.s}</span>
            <div className={`mb-img-placeholder ${p.color}`} style={{ aspectRatio: "1", borderRadius: 8, marginBottom: 8 }}>·</div>
            <div style={{ fontSize: 12, fontWeight: 500 }}>{p.n}</div>
            <div style={{ fontSize: 12, color: "var(--mb-gold)", fontWeight: 600, marginTop: 3 }}>৳{p.p}</div>
          </div>
        ))}
      </div>
      <button className="mb-btn mb-btn-primary" style={{ width: "100%", marginTop: 12 }}>Add full routine · ৳3,650</button>
    </div>
  </MobileFrame>
);

Object.assign(window, { DirectionA_Mobile, DirectionB_Mobile, DirectionC_Mobile });
