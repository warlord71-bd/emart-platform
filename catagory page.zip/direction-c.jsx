/* DIRECTION C — Concern-First Routine Builder
   Engagement lever: combines visual storytelling + social proof.
   Skin Quiz front-and-center + interactive concern → routine flow.
   Categories arrive AFTER you've told us about you. */

const DirectionC_Desktop = () => {
  return (
    <div className="mb-artboard" style={{ width: "100%", minHeight: "100%" }}>
      <TopBar />

      {/* Quiz hero */}
      <div style={{
        background: "var(--mb-cream)",
        padding: "40px 24px 50px",
        position: "relative",
      }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, alignItems: "center" }}>
          <div>
            <div className="mb-eyebrow">— Step 01 · Tell us about you</div>
            <h1 className="mb-h-display" style={{ fontSize: 56, lineHeight: 1.05, margin: "12px 0 14px", color: "var(--mb-navy)" }}>
              Skip the guesswork.<br/>
              Build your <em style={{ color: "var(--mb-pink)" }}>routine</em>.
            </h1>
            <p style={{ fontSize: 15.5, color: "var(--mb-ink-2)", margin: "0 0 24px", maxWidth: 460, lineHeight: 1.55 }}>
              Answer 6 questions. We'll match you to verified products from 250 brands — sorted by what actually works for your skin, hair, or vibe.
            </p>

            {/* Inline quiz starter */}
            <div style={{
              background: "#fff",
              border: "1px solid var(--mb-line)",
              borderRadius: "var(--mb-radius-lg)",
              padding: 22,
              boxShadow: "var(--mb-shadow)",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <span style={{ fontSize: 11, letterSpacing: ".15em", color: "var(--mb-ink-3)" }}>QUESTION 1 / 6</span>
                <div style={{ flex: 1, height: 3, background: "var(--mb-cream)", borderRadius: 999, margin: "0 14px", overflow: "hidden" }}>
                  <div style={{ width: "16%", height: "100%", background: "var(--mb-pink)" }} />
                </div>
                <span style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>~60 sec</span>
              </div>
              <div className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-navy)", marginBottom: 14 }}>
                What are you shopping for today?
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                {[
                  ["Skincare","ত্বক"],
                  ["Makeup","মেকআপ"],
                  ["Hair","চুল"],
                  ["Fragrance","সুগন্ধি"],
                  ["Body","শরীর"],
                  ["Wellness","সুস্থতা"],
                ].map(([n, bn], i) => (
                  <button key={i} style={{
                    padding: "12px 10px",
                    background: i === 0 ? "var(--mb-navy)" : "#fff",
                    color: i === 0 ? "#fff" : "var(--mb-navy)",
                    border: i === 0 ? "1px solid var(--mb-navy)" : "1px solid var(--mb-line)",
                    borderRadius: 10,
                    cursor: "pointer",
                    textAlign: "left",
                  }}>
                    <div style={{ fontSize: 13.5, fontWeight: 500 }}>{n}</div>
                    <div className="mb-bn" style={{ fontSize: 11, opacity: .65, marginTop: 2 }}>{bn}</div>
                  </button>
                ))}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16 }}>
                <span style={{ fontSize: 11.5, color: "var(--mb-ink-3)" }}>Skip & browse all categories →</span>
                <button className="mb-btn mb-btn-primary" style={{ height: 38 }}>Next <Icon name="arrow-right" size={14} /></button>
              </div>
            </div>
          </div>

          {/* Right: visual story */}
          <div style={{ position: "relative", height: 540 }}>
            <div className="mb-img-placeholder pink" style={{
              position: "absolute", top: 0, right: 30, width: 280, height: 360,
              borderRadius: "var(--mb-radius-lg)", transform: "rotate(-3deg)", border: "8px solid #fff", boxShadow: "var(--mb-shadow-lg)",
            }}>
              model · routine
            </div>
            <div className="mb-img-placeholder gold" style={{
              position: "absolute", bottom: 30, left: 0, width: 220, height: 280,
              borderRadius: "var(--mb-radius-lg)", transform: "rotate(4deg)", border: "8px solid #fff", boxShadow: "var(--mb-shadow-lg)",
            }}>
              flatlay · 4 products
            </div>
            <div style={{
              position: "absolute", top: 80, left: 60,
              background: "var(--mb-navy)", color: "#fff",
              padding: "12px 18px", borderRadius: 14,
              boxShadow: "var(--mb-shadow-lg)",
              maxWidth: 200,
            }}>
              <div style={{ fontSize: 11, color: "var(--mb-gold-soft)", letterSpacing: ".1em", textTransform: "uppercase" }}>For Asha, age 26</div>
              <div className="mb-h-display" style={{ fontSize: 18, marginTop: 4 }}>"My 4-step routine."</div>
              <div style={{ fontSize: 12, opacity: .7, marginTop: 4 }}>Combination · Sensitive</div>
            </div>
            <div style={{
              position: "absolute", bottom: 90, right: 0,
              background: "#fff", padding: "10px 14px",
              borderRadius: 12, border: "1px solid var(--mb-line)",
              boxShadow: "var(--mb-shadow)",
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--mb-pink)" }}>96k</div>
              <div style={{ fontSize: 11, color: "var(--mb-ink-2)", lineHeight: 1.3 }}>routines<br/>built so far</div>
            </div>
          </div>
        </div>
      </div>

      {/* Or browse — big category tiles */}
      <div style={{ padding: "44px 24px 16px" }}>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div className="mb-eyebrow mb-eyebrow-gold">— Or browse straight in</div>
          <h2 className="mb-h-display" style={{ fontSize: 32, color: "var(--mb-navy)", margin: "6px 0 0" }}>Six worlds. One trolley.</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
          {[
            { n: "Skincare", bn: "ত্বক", p: 2840, color: "pink" },
            { n: "Makeup", bn: "মেকআপ", p: 1620, color: "gold" },
            { n: "Hair", bn: "চুল", p: 920, color: "pink" },
            { n: "Fragrance", bn: "সুগন্ধি", p: 480, color: "navy" },
            { n: "Body", bn: "শরীর", p: 760, color: "gold" },
            { n: "Wellness", bn: "সুস্থতা", p: 320, color: "pink" },
          ].map((c, i) => (
            <div key={i} style={{
              borderRadius: "var(--mb-radius)",
              border: "1px solid var(--mb-line)",
              overflow: "hidden",
              background: "#fff",
              cursor: "pointer",
            }}>
              <div className={`mb-img-placeholder ${c.color}`} style={{ aspectRatio: "4/5" }}>
                {c.n.toLowerCase()}
              </div>
              <div style={{ padding: 14, textAlign: "center" }}>
                <div className="mb-bn" style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>{c.bn}</div>
                <div className="mb-h-display" style={{ fontSize: 18, color: "var(--mb-navy)", marginTop: 2 }}>{c.n}</div>
                <div style={{ fontSize: 11, color: "var(--mb-ink-3)", marginTop: 4 }}>{c.p.toLocaleString()} items</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Concern → Routine builder */}
      <div style={{ padding: "44px 24px", background: "var(--mb-navy)", color: "#fff", marginTop: 32 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: 32 }}>
          <div>
            <span className="mb-badge" style={{ background: "rgba(212,162,72,.18)", color: "var(--mb-gold)" }}>✦ ROUTINE BUILDER</span>
            <h2 className="mb-h-display" style={{ fontSize: 36, lineHeight: 1.1, margin: "14px 0 14px" }}>
              Pick a concern.<br/>Get a 4-step routine.
            </h2>
            <p style={{ fontSize: 14, color: "rgba(255,255,255,.6)", lineHeight: 1.55, margin: 0 }}>
              Every concern below opens a curated AM/PM routine — built by E-Mart's licensed estheticians, tuned to Bangladesh's climate.
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 18 }}>
              {["Acne & Blemish","Dullness","Hyperpigmentation","Sensitivity","Pores","Anti-Ageing","Dry Skin","Oily Skin"].map((x, i) => (
                <span key={x} style={{
                  padding: "7px 14px", borderRadius: 999, fontSize: 12,
                  background: i === 1 ? "var(--mb-pink)" : "rgba(255,255,255,.08)",
                  color: i === 1 ? "#fff" : "rgba(255,255,255,.85)",
                  border: i === 1 ? "1px solid var(--mb-pink)" : "1px solid rgba(255,255,255,.12)",
                  cursor: "pointer",
                }}>{x}</span>
              ))}
            </div>
          </div>

          {/* Routine preview — 4 steps */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <span style={{ fontSize: 11, letterSpacing: ".15em", opacity: .5 }}>SHOWING ROUTINE FOR · DULLNESS</span>
              <span style={{ fontSize: 12, color: "var(--mb-pink-soft)" }}>Bundle all 4 · save ৳420 →</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
              {[
                { s: 1, n: "Gentle Foam", b: "Tula", p: 480, color: "pink" },
                { s: 2, n: "Vit C Serum", b: "Lumière", p: 1490, color: "gold" },
                { s: 3, n: "Ceramide Cream", b: "Nuvo", p: 1180, color: "pink" },
                { s: 4, n: "SPF 50 PA+++", b: "Lumière", p: 920, color: "gold" },
              ].map((p) => (
                <div key={p.s} style={{
                  background: "rgba(255,255,255,.05)",
                  border: "1px solid rgba(255,255,255,.1)",
                  borderRadius: "var(--mb-radius)",
                  padding: 12,
                  position: "relative",
                }}>
                  <span className="mb-h-display" style={{ position: "absolute", top: 10, right: 12, fontSize: 28, color: "rgba(212,162,72,.4)" }}>0{p.s}</span>
                  <div className={`mb-img-placeholder ${p.color}`} style={{ aspectRatio: "1", borderRadius: 10, marginBottom: 10 }}>product</div>
                  <div style={{ fontSize: 10, opacity: .55, textTransform: "uppercase", letterSpacing: ".08em" }}>Step {p.s} · {p.b}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, marginTop: 2 }}>{p.n}</div>
                  <div style={{ fontSize: 13, color: "var(--mb-gold)", fontWeight: 600, marginTop: 6 }}>৳{p.p}</div>
                </div>
              ))}
            </div>
            <button className="mb-btn mb-btn-primary" style={{ width: "100%", marginTop: 14 }}>
              Add full routine to cart · ৳3,650 <Icon name="bag" size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Bestsellers narrow row + brands */}
      <div style={{ padding: "44px 24px" }}>
        <div className="mb-eyebrow">— Bestsellers across categories</div>
        <h2 className="mb-h-display" style={{ fontSize: 28, color: "var(--mb-navy)", margin: "6px 0 18px" }}>What's flying off shelves this week.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10 }}>
          <MiniProduct brand="LUMIÈRE BD" name="Niacinamide 10% Serum" price="1,490" oldPrice="1,890" badge="−21%" color="pink" />
          <MiniProduct brand="NOOR STUDIO" name="Velvet Matte Lipstick" price="850" badge="NEW" color="gold" />
          <MiniProduct brand="AROMA HOUSE" name="Oud Attar 12ml" price="2,200" oldPrice="2,600" badge="EDITOR'S" color="navy" />
          <MiniProduct brand="SHABA CO." name="Argan Hair Oil 100ml" price="680" oldPrice="1,290" badge="−47%" color="gold" />
          <MiniProduct brand="TULA BOTANIC" name="Rose Water Toner" price="590" oldPrice="990" badge="POPULAR" color="pink" />
          <MiniProduct brand="NUVO" name="Ceramide Night Cream" price="1,180" badge="BUNDLE" color="navy" />
        </div>
      </div>

      <TrustStrip />
      <FooterMini />
    </div>
  );
};

window.DirectionC_Desktop = DirectionC_Desktop;
