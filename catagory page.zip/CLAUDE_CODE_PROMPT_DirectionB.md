# Claude Code Prompt — Implement Direction B (Live Pulse) for e-mart.com.bd /categories

## Mission
Replace the existing `/categories` page on **e-mart.com.bd** with the **Direction B · Live Pulse** wireframe (see `direction-b.jsx` + `E-Mart BD Category Page.html` in the design project). Wire every static block to the live product/category/order data already in our codebase. Keep the **Midnight Blossom** design system intact — do not invent new colors, fonts, or radii.

## Design system (lock these tokens — copy into theme/tokens file)
```css
--mb-navy: #1B1B2F;       --mb-navy-2: #25253E;     --mb-navy-3: #2F2F4A;
--mb-pink: #E8739E;       --mb-pink-soft: #F5C2D5;  --mb-pink-bg: #FBE8EF;
--mb-gold: #D4A248;       --mb-gold-soft: #EAC986;
--mb-cream: #FAF6EE;      --mb-paper: #FFFDF8;
--mb-ink: #1B1B2F;        --mb-ink-2: #4A4A63;      --mb-ink-3: #7A7A8E;
--mb-line: #E6E1D6;       --mb-success: #3FA572;    --mb-danger: #D9534F;
--mb-radius-sm: 8px;      --mb-radius: 14px;        --mb-radius-lg: 22px;
--font-display: "Playfair Display", Georgia, serif;
--font-sans: "Jost", system-ui, sans-serif;
--font-bn: "Hind Siliguri", "Jost", sans-serif;
```
Load fonts from Google Fonts (`Jost 400/500/600/700`, `Playfair Display 400/500/600/700`, `Hind Siliguri 400/500/600`).

## Page structure (top → bottom) — EXACT order

1. **TopBar** (existing component if any — extend, don't replace)
   - Top utility row (navy bg): free-delivery line in Bangla, Track Order, EN/বাং toggle, Help.
   - Main bar: logo, search input, user/wishlist/bag icons with live cart count.

2. **Live Ticker Bar** ⚡ NEW — `<LiveTickerBar />`
   - Navy background, marquee-style scrolling.
   - Pulls from THREE live sources, rotates every 4s:
     a. **Live shopper count** — `GET /api/analytics/active-sessions` (fall back to a heartbeat WebSocket `wss://api.e-mart.com.bd/ws/presence` if available).
     b. **Recent purchases** — `GET /api/orders/recent?limit=10&fields=customer_first_name,city,product_name,timestamp` — anonymise as "Asha M. from Chittagong just bought…". Filter to last 5 minutes.
     c. **Active flash deal countdown** — pulled from the same source as section 4 below.
   - Component must auto-update via SWR/React Query w/ 30s revalidate. WebSocket if available is preferred.

3. **Hero — Flash Week** `<FlashWeekHero />`
   - Two-column. Left: title + 3-segment countdown (HH/MM/SS) + CTA "Shop the deals".
   - Right: **TrendingNowLeaderboard** — top 4 fastest-rising SKUs in last 6h.
     - Endpoint: `GET /api/products/trending?window=6h&limit=4&include=growth_rate,stock_remaining`.
     - Shows rank, name, brand, growth %, stock left. Stock < 15 turns red.
   - Countdown reads `GET /api/promotions/active?type=flash_week` → pick the one with nearest `ends_at`. Compute `now - ends_at` client-side; tick every 1s; refetch every 60s to stay synced.

4. **TrustStrip** — static (4 columns: free delivery, authentic, 7-day return, payment methods).

5. **Category Sub-nav** — `<CategoryChips />`
   - Pulls from `GET /api/categories?level=1&include=is_trending`.
   - Always-present chips: All, 🔥 Trending, then DB categories. Sort by `display_order`.
   - Sticky on scroll past hero.

6. **Popular Categories Grid** `<PopularCategoriesGrid />` — 4-col × 2-row (8 cards).
   - Endpoint: `GET /api/categories/popular?limit=8&window=7d&include=product_count,trend_pct,active_viewers,is_hot`.
   - Per card:
     - Avatar circle = category abbreviation OR `category.icon_url` if present.
     - Name + product count.
     - **Trend bar** — `width: trend_pct%`, gradient pink→gold.
     - "↑ {trend}% this week" (green if positive, red if negative).
     - "🟢 {active_viewers} viewing" — comes from same active-sessions endpoint, filtered by category.
     - **HOT badge** — `is_hot === true` (DB rule: trend_pct > 60% OR rank moved up ≥ 3 slots).
   - Click → `/category/{slug}`.

7. **Flash Deals Row** `<FlashDealsRow />` — 5 cards, horizontally scrollable on mobile.
   - Endpoint: `GET /api/products?promotion=flash&active=true&limit=5&sort=stock_velocity_desc&include=stock_sold,stock_total,original_price,sale_price,brand`.
   - Per card: image, brand, name, sale price, struck original price, **discount badge** (`Math.round((1 - sale/original) * 100)%`), **stock progress bar**.
   - Stock bar:
     - Width: `(sold / total) * 100%`.
     - Color: gold if sold ≤ 80%, red if > 80%.
     - Label: "🔥 {sold} sold" + "{remaining} left". When < 10 remaining: pulse + red.
   - Section header has a **mirror countdown** (same flash deal as hero — share state via context or Zustand store, do NOT fetch twice).

8. **Shop by Skin Concern** `<ConcernGrid />` — 4 cards.
   - Endpoint: `GET /api/concerns?include=product_count,review_count,avg_rating,top_product`.
   - Per card: name, star rating, review count, "Most-loved: {top_product.name}", product count, browse arrow.
   - Click → `/concerns/{slug}`.

9. **Customer Wall** `<CustomerWall />` — 3 reviews.
   - Endpoint: `GET /api/reviews/featured?limit=3&min_rating=5&verified=true&recent_days=14&include=product,customer_first_name,customer_city`.
   - Display: 5-star, quote, name + city + "Verified", linked product name.

10. **FooterMini** — existing footer, no changes.

## Real-time / live behavior contract
- **Active viewers** counter (ticker + per-category): increments/decrements via WS message `{type:"presence", category_id, delta}`. Polling fallback every 30s.
- **Stock counters**: optimistic decrement on `order.placed` SSE event. WS topic `stock:updates`.
- **Flash countdown**: single source of truth in a `<FlashContext>`; ALL countdowns subscribe.
- **Recent purchase ticker**: subscribe to `wss://api.e-mart.com.bd/ws/orders` topic, debounce 4s between messages.
- All real-time UIs MUST degrade gracefully if WS fails — fall back to interval polling, never blank state.

## Bangla / i18n
- All strings go through existing i18n system. Keys live under `category_page.*`.
- Numbers: format with `Intl.NumberFormat('bn-BD')` when locale is `bn`, else `en-BD`.
- Currency: `৳` prefix, no space. Format `1,490` not `1490`.
- Critical strings already in design (translate both EN & BN):
  - "Shoppers browsing right now" / "এখন কেনাকাটা করছেন"
  - "Flash deal ends in" / "ফ্ল্যাশ ডিল শেষ হবে"
  - "left" / "বাকি"
  - "sold" / "বিক্রি হয়েছে"
  - "Verified" / "যাচাইকৃত"

## Performance budget
- Hero LCP < 2.0s on Bangladesh 4G.
- Trending leaderboard cached at edge for 60s.
- Category grid SSR'd with ISR (`revalidate: 60`).
- Trust strip + footer fully static.
- Live components hydrated client-side only — wrap in `<Suspense>` with skeletons.
- Mobile bundle < 180KB gzipped for this route.

## Mobile (≤ 640px)
Match `DirectionB_Mobile` exactly:
- Compact ticker (count + countdown only, no recent-purchase cycle).
- Hero collapses countdown to one row of 3 small tiles.
- Trending leaderboard becomes 3 stacked rows (drop rank 4).
- Popular categories: 2-col grid, 4 cards visible (rest behind "See all").
- Flash deals: horizontal scroll snap.
- Bottom tab bar persists: Browse · Quiz · Wishlist · Cart · Me.

## Files to touch (best guess — adjust to repo reality)
- `app/categories/page.tsx` (or `pages/categories/index.tsx`)
- `components/categories/LiveTickerBar.tsx` ⚡ new
- `components/categories/FlashWeekHero.tsx` ⚡ new
- `components/categories/TrendingLeaderboard.tsx` ⚡ new
- `components/categories/PopularCategoriesGrid.tsx` ⚡ new
- `components/categories/FlashDealsRow.tsx` ⚡ new
- `components/categories/ConcernGrid.tsx` ⚡ new
- `components/categories/CustomerWall.tsx` ⚡ new
- `components/shared/StockBar.tsx` ⚡ new (reuse on PDP later)
- `lib/realtime/presence.ts` ⚡ new (WS + polling fallback)
- `lib/realtime/flash-context.tsx` ⚡ new
- `styles/midnight-blossom.css` ⚡ new (the tokens above)

## Backend endpoints to verify / build
Run a quick audit. For each missing endpoint, scaffold an admin-friendly handler:
- [ ] `GET /api/analytics/active-sessions?category_id?`
- [ ] `GET /api/orders/recent?limit&fields`
- [ ] `GET /api/promotions/active?type`
- [ ] `GET /api/products/trending?window&limit`
- [ ] `GET /api/categories/popular?window&include`
- [ ] `GET /api/products?promotion=flash&...`
- [ ] `GET /api/concerns?...`
- [ ] `GET /api/reviews/featured?...`
- [ ] WS: `presence`, `orders`, `stock:updates`

## Acceptance criteria
1. `/categories` renders the new page with **zero hardcoded product/category data**.
2. Lighthouse mobile ≥ 90 perf, ≥ 95 a11y.
3. Countdown across hero & flash row stays in sync to the second.
4. With WS up: live shopper count updates within 5s of opening a second tab.
5. With WS down: page still renders & polls every 30s; no console errors.
6. Bangla locale toggle swaps every visible string + reformats all numbers/currency.
7. Stock < 10 triggers red+pulse on the stock bar.
8. Trending leaderboard refreshes every 60s without layout shift.
9. Visual diff vs. `direction-b.jsx` (desktop @1280) within ±4px on every section boundary.
10. All new components are storybook-documented + have unit tests for empty/error/loading states.

## How to start
1. Run `pnpm dev` and open `/categories`.
2. Read existing `/categories` route + any cross-cutting layout / theme files.
3. Drop the Midnight Blossom tokens into the global stylesheet **without** breaking other routes (scope under a `[data-theme="midnight-blossom"]` if needed).
4. Build top-down: TopBar tweaks → Ticker → Hero → … → CustomerWall.
5. Wire one component to live data fully before moving to the next — no parallel half-built pieces.
6. Commit per component with screenshots in the PR description.

## What NOT to do
- Don't ship without empty/error/loading states on every live component.
- Don't fake the live ticker with a static array — if data isn't ready, hide the ticker entirely behind a feature flag.
- Don't use `Inter`, `Roboto`, or any other font outside the trio above.
- Don't increase color count. Saturated reds/greens only for stock urgency + trend deltas.
- Don't add a hero carousel. The page already has enough motion.
- Don't add chatbot, cookie banner, or popup modals to this route — those are owned elsewhere.

## Reference files
- `direction-b.jsx` — full desktop component spec
- `mobile.jsx` → `DirectionB_Mobile` — mobile spec
- `tokens.css` — exact CSS variables
- `shared.jsx` — Icon set, StarRating, MiniProduct, TopBar, TrustStrip, FooterMini
- `E-Mart BD Category Page.html` — render the wireframe locally to compare pixel-by-pixel
