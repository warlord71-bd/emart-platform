/* Shared atoms used across the three category-page directions.
   Exposed on window so each direction file can use them. */

const Icon = ({ name, size = 16, color = "currentColor", stroke = 1.6 }) => {
  const s = { width: size, height: size, fill: "none", stroke: color, strokeWidth: stroke, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "search": return <svg viewBox="0 0 24 24" {...s}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>;
    case "heart": return <svg viewBox="0 0 24 24" {...s}><path d="M20.8 5.6a5.5 5.5 0 0 0-7.8 0L12 6.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 22.2l7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>;
    case "bag": return <svg viewBox="0 0 24 24" {...s}><path d="M5 7h14l-1.2 12.2a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 7z"/><path d="M9 7V5a3 3 0 0 1 6 0v2"/></svg>;
    case "user": return <svg viewBox="0 0 24 24" {...s}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>;
    case "menu": return <svg viewBox="0 0 24 24" {...s}><path d="M4 6h16M4 12h16M4 18h16"/></svg>;
    case "arrow-right": return <svg viewBox="0 0 24 24" {...s}><path d="M5 12h14M13 6l6 6-6 6"/></svg>;
    case "arrow-up-right": return <svg viewBox="0 0 24 24" {...s}><path d="M7 17 17 7M9 7h8v8"/></svg>;
    case "chevron-right": return <svg viewBox="0 0 24 24" {...s}><path d="m9 6 6 6-6 6"/></svg>;
    case "chevron-down": return <svg viewBox="0 0 24 24" {...s}><path d="m6 9 6 6 6-6"/></svg>;
    case "star": return <svg viewBox="0 0 24 24" fill={color} stroke="none"><path d="M12 2l2.9 6.6 7.1.7-5.4 4.8 1.6 7L12 17.6 5.8 21l1.6-7L2 9.3l7.1-.7L12 2z"/></svg>;
    case "sparkle": return <svg viewBox="0 0 24 24" {...s}><path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3"/></svg>;
    case "fire": return <svg viewBox="0 0 24 24" {...s}><path d="M12 3s4 4 4 8a4 4 0 0 1-8 0c0-1 .5-2 1-2.5C9 11 8 12 8 14a4 4 0 0 0 8 0c0-3-2-5-4-7-2 2-4 4-4 7a4 4 0 0 0 8 0"/></svg>;
    case "clock": return <svg viewBox="0 0 24 24" {...s}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>;
    case "play": return <svg viewBox="0 0 24 24" fill={color} stroke="none"><path d="M8 5v14l11-7z"/></svg>;
    case "verified": return <svg viewBox="0 0 24 24" {...s}><path d="M12 2 14.5 4 17.5 3.5 18.5 6.5 21 8l-1 3 1 3-2.5 1.5-1 3-3-.5L12 22l-2.5-2-3 .5-1-3L3 14l1-3-1-3 2.5-1.5 1-3L9.5 4 12 2z"/><path d="m9 12 2 2 4-4"/></svg>;
    case "globe": return <svg viewBox="0 0 24 24" {...s}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>;
    case "filter": return <svg viewBox="0 0 24 24" {...s}><path d="M4 5h16M7 12h10M10 19h4"/></svg>;
    case "trend": return <svg viewBox="0 0 24 24" {...s}><path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/></svg>;
    case "leaf": return <svg viewBox="0 0 24 24" {...s}><path d="M11 21c-4 0-8-3-8-8 0-7 8-10 16-10 0 8-3 18-8 18-2 0-4-1-4-4 0-3 4-7 8-7"/></svg>;
    case "package": return <svg viewBox="0 0 24 24" {...s}><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/></svg>;
    case "shield": return <svg viewBox="0 0 24 24" {...s}><path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5l-8-3z"/></svg>;
    case "truck": return <svg viewBox="0 0 24 24" {...s}><path d="M3 7h11v10H3zM14 10h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>;
    default: return null;
  }
};

const StarRating = ({ value = 4.7, size = 12 }) => (
  <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>
    {[1,2,3,4,5].map(i => (
      <Icon key={i} name="star" size={size} color={i <= Math.round(value) ? "#D4A248" : "#E6E1D6"} />
    ))}
  </span>
);

/* Mini product card (used in side rails) */
const MiniProduct = ({ name, brand, price, oldPrice, badge, color = "pink", rating = 4.7, reviews = 234 }) => (
  <div style={{
    background: "#fff",
    borderRadius: 12,
    border: "1px solid var(--mb-line)",
    padding: 10,
    display: "flex",
    gap: 10,
    alignItems: "center",
  }}>
    <div className={`mb-img-placeholder ${color}`} style={{ width: 56, height: 56, borderRadius: 8, flexShrink: 0 }}>
      product
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 10, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>{brand}</div>
      <div style={{ fontSize: 12.5, fontWeight: 500, color: "var(--mb-ink)", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
        <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--mb-pink)" }}>৳{price}</span>
        {oldPrice && <span style={{ fontSize: 11, color: "var(--mb-ink-3)", textDecoration: "line-through" }}>৳{oldPrice}</span>}
        {badge && <span className="mb-badge mb-badge-pink" style={{ fontSize: 9, padding: "1px 5px" }}>{badge}</span>}
      </div>
    </div>
  </div>
);

/* Header bar */
const TopBar = ({ compact = false }) => (
  <div style={{ borderBottom: "1px solid var(--mb-line)" }}>
    {!compact && (
      <div style={{
        background: "var(--mb-navy)",
        color: "rgba(255,255,255,.85)",
        fontSize: 12,
        padding: "8px 24px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Icon name="truck" size={14} color="#D4A248" />
          ফ্রি ডেলিভারি ৳1,500+ অর্ডারে · Cash on delivery available
        </span>
        <span style={{ display: "flex", gap: 18 }}>
          <span>Track Order</span>
          <span>EN · বাং</span>
          <span>Help</span>
        </span>
      </div>
    )}
    <div style={{
      padding: "16px 24px",
      display: "flex",
      alignItems: "center",
      gap: 24,
      background: "#fff",
    }}>
      <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700, color: "var(--mb-navy)", letterSpacing: "-0.01em" }}>
        E-Mart<span style={{ color: "var(--mb-pink)" }}>.</span><span style={{ fontSize: 12, color: "var(--mb-gold)", fontFamily: "var(--font-sans)", fontWeight: 500, marginLeft: 4 }}>BD</span>
      </div>
      <div style={{
        flex: 1,
        height: 40,
        borderRadius: 999,
        background: "var(--mb-cream)",
        border: "1px solid var(--mb-line)",
        display: "flex",
        alignItems: "center",
        padding: "0 14px",
        gap: 8,
        color: "var(--mb-ink-3)",
        fontSize: 13.5,
      }}>
        <Icon name="search" size={16} />
        <span>Search 12,000+ products · serums, lipsticks, perfumes…</span>
      </div>
      <div style={{ display: "flex", gap: 18, color: "var(--mb-ink)", alignItems: "center" }}>
        <Icon name="user" size={20} />
        <Icon name="heart" size={20} />
        <div style={{ position: "relative" }}>
          <Icon name="bag" size={20} />
          <span style={{
            position: "absolute", top: -4, right: -8,
            background: "var(--mb-pink)", color: "#fff",
            fontSize: 9, fontWeight: 700,
            width: 16, height: 16, borderRadius: 999,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>3</span>
        </div>
      </div>
    </div>
  </div>
);

/* Trust strip — payment & shipping signals (BD-specific) */
const TrustStrip = () => (
  <div style={{
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: 0,
    borderTop: "1px solid var(--mb-line)",
    borderBottom: "1px solid var(--mb-line)",
    background: "var(--mb-cream)",
  }}>
    {[
      { i: "truck", t: "Free Delivery", s: "৳1,500+ all over BD" },
      { i: "shield", t: "100% Authentic", s: "Verified by E-Mart Lab" },
      { i: "package", t: "Easy 7-day Return", s: "No-questions refund" },
      { i: "verified", t: "bKash · Nagad · COD", s: "Pay your way" },
    ].map((x, i) => (
      <div key={i} style={{
        padding: "14px 18px",
        display: "flex", gap: 12, alignItems: "center",
        borderRight: i < 3 ? "1px solid var(--mb-line)" : "none",
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: "#fff",
          border: "1px solid var(--mb-line)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--mb-pink)",
        }}>
          <Icon name={x.i} size={18} />
        </div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--mb-navy)" }}>{x.t}</div>
          <div style={{ fontSize: 11.5, color: "var(--mb-ink-3)" }}>{x.s}</div>
        </div>
      </div>
    ))}
  </div>
);

/* Footer mini */
const FooterMini = () => (
  <div style={{
    background: "var(--mb-navy)",
    color: "rgba(255,255,255,.7)",
    padding: "28px 24px 22px",
    fontSize: 12.5,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 24,
  }}>
    <div style={{ maxWidth: 220 }}>
      <div style={{ fontFamily: "var(--font-display)", color: "#fff", fontSize: 18, marginBottom: 6 }}>E-Mart<span style={{ color: "var(--mb-pink)" }}>.</span></div>
      <div style={{ lineHeight: 1.5 }}>Bangladesh's beauty destination. 12,000+ products, 250+ brands, all authentic.</div>
    </div>
    {[
      ["Shop", ["Skincare","Makeup","Hair","Body","Fragrance"]],
      ["Help", ["Contact","Returns","Shipping","FAQ","Authenticity"]],
      ["Pay", ["bKash","Nagad","Rocket","Visa / Mastercard","Cash on Delivery"]],
    ].map(([h, items], i) => (
      <div key={i}>
        <div style={{ color: "#fff", fontWeight: 500, marginBottom: 8, letterSpacing: ".04em", textTransform: "uppercase", fontSize: 11 }}>{h}</div>
        {items.map(x => <div key={x} style={{ marginBottom: 4 }}>{x}</div>)}
      </div>
    ))}
  </div>
);

Object.assign(window, { Icon, StarRating, MiniProduct, TopBar, TrustStrip, FooterMini });
