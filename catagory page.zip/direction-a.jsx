/* DIRECTION A — Editorial Showcase
   Engagement lever: Visual storytelling.
   Big animated hero, magazine-style category showcase, lifestyle imagery,
   editor's picks, founder quotes, "Behind the brand" mini-stories. */

const DirectionA_Desktop = () => {
  const categories = [
    { name: "Skincare", bn: "ত্বক", products: 2840, color: "pink", featured: "Glass-skin routines" },
    { name: "Makeup", bn: "মেকআপ", products: 1620, color: "gold", featured: "Festive looks for Eid" },
    { name: "Fragrance", bn: "সুগন্ধি", products: 480, color: "navy", featured: "Attar & Eau de parfum" },
    { name: "Hair", bn: "চুল", products: 920, color: "pink", featured: "Monsoon-proof care" },
    { name: "Body", bn: "শরীর", products: 760, color: "gold", featured: "Bath rituals" },
    { name: "Wellness", bn: "সুস্থতা", products: 320, color: "navy", featured: "Inner glow" },
  ];

  return (
    <div className="mb-artboard" style={{ width: "100%", minHeight: "100%" }}>
      <TopBar />

      {/* Sub-nav: category tabs (sticky-feel) */}
      <div style={{
        display: "flex", gap: 6, padding: "12px 24px",
        borderBottom: "1px solid var(--mb-line)",
        background: "#fff",
        overflowX: "auto",
      }} className="mb-noscroll">
        <span className="mb-chip" data-active="true">All Categories</span>
        <span className="mb-chip">Popular</span>
        <span className="mb-chip">By Concern</span>
        <span className="mb-chip">Skin Quiz</span>
        <span className="mb-chip">Skincare</span>
        <span className="mb-chip">Makeup</span>
        <span className="mb-chip">Hair</span>
        <span className="mb-chip">Fragrance</span>
        <span className="mb-chip">Body</span>
        <span className="mb-chip">Wellness</span>
        <span className="mb-chip">Tools</span>
        <span className="mb-chip">New In</span>
      </div>

      {/* Editorial hero */}
      <div style={{ padding: "36px 24px 0", background: "linear-gradient(180deg, var(--mb-cream), #fff 60%)" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 28, alignItems: "stretch" }}>
          {/* Left: title block */}
          <div style={{ paddingTop: 22 }}>
            <div className="mb-eyebrow">— Issue 04 · Spring Edit</div>
            <h1 className="mb-h-display" style={{ fontSize: 64, lineHeight: 1.02, margin: "12px 0 16px", color: "var(--mb-navy)" }}>
              The <em style={{ color: "var(--mb-pink)", fontStyle: "italic" }}>Beauty</em> Atlas<br/>
              of Bangladesh.
            </h1>
            <p style={{ fontSize: 16, lineHeight: 1.6, color: "var(--mb-ink-2)", maxWidth: 460, margin: 0 }}>
              Twelve thousand products. Two-fifty brands. One curated journey through skincare, scent, and self-care — chosen by our editors and your reviews.
            </p>
            <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
              <button className="mb-btn mb-btn-dark"><Icon name="sparkle" size={14} color="#D4A248" /> Take the 60-sec Skin Quiz</button>
              <button className="mb-btn mb-btn-ghost">Browse the Edit <Icon name="arrow-right" size={14} /></button>
            </div>
            <div style={{ display: "flex", gap: 28, marginTop: 28, paddingTop: 22, borderTop: "1px solid var(--mb-line)" }}>
              {[
                ["12,400+", "products"],
                ["250+", "verified brands"],
                ["96k", "happy customers"],
                ["4.8★", "avg rating"],
              ].map(([n, l]) => (
                <div key={l}>
                  <div className="mb-h-display" style={{ fontSize: 22, color: "var(--mb-navy)" }}>{n}</div>
                  <div style={{ fontSize: 11, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".1em", marginTop: 2 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
          {/* Right: editorial collage */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 10, height: 460 }}>
            <div className="mb-img-placeholder pink" style={{ borderRadius: "var(--mb-radius)", gridRow: "1 / span 2", position: "relative" }}>
              hero · model w/ serum
              <div style={{ position: "absolute", left: 14, bottom: 14, right: 14 }}>
                <span className="mb-badge mb-badge-navy">EDITOR'S COVER</span>
                <div style={{ color: "#fff", textShadow: "0 2px 12px rgba(0,0,0,.4)", fontFamily: "var(--font-display)", fontSize: 22, marginTop: 8, lineHeight: 1.15 }}>
                  The dewy era,<br/>made local.
                </div>
              </div>
            </div>
            <div className="mb-img-placeholder gold" style={{ borderRadius: "var(--mb-radius)" }}>flatlay · 6 bottles</div>
            <div className="mb-img-placeholder navy" style={{ borderRadius: "var(--mb-radius)", flexDirection: "column", gap: 6 }}>
              <Icon name="play" size={28} color="#fff" />
              <span style={{ color: "#fff" }}>Watch · 0:42</span>
            </div>
          </div>
        </div>
      </div>

      {/* Animated category showcase */}
      <div style={{ padding: "48px 24px 12px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 18 }}>
          <div>
            <div className="mb-eyebrow mb-eyebrow-gold">— Six worlds, one cart</div>
            <h2 className="mb-h-display" style={{ fontSize: 36, color: "var(--mb-navy)", margin: "6px 0 0" }}>Step into a category.</h2>
          </div>
          <div style={{ display: "flex", gap: 8, color: "var(--mb-ink-3)", fontSize: 13 }}>
            <span>← Drag to explore →</span>
          </div>
        </div>

        {/* Big horizontal magazine cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {categories.slice(0, 3).map((c, i) => (
            <div key={i} style={{
              position: "relative",
              borderRadius: "var(--mb-radius-lg)",
              overflow: "hidden",
              aspectRatio: "3 / 4",
              border: "1px solid var(--mb-line)",
              cursor: "pointer",
            }}>
              <div className={`mb-img-placeholder ${c.color}`} style={{ position: "absolute", inset: 0 }}>
                editorial · {c.name.toLowerCase()}
              </div>
              <div style={{
                position: "absolute", inset: 0,
                background: "linear-gradient(180deg, transparent 40%, rgba(27,27,47,.85))",
              }} />
              <div style={{ position: "absolute", top: 14, left: 14, right: 14, display: "flex", justifyContent: "space-between" }}>
                <span className="mb-badge mb-badge-navy" style={{ background: "rgba(255,255,255,.18)", backdropFilter: "blur(8px)", color: "#fff" }}>0{i+1} / 06</span>
                <span style={{ color: "#fff", fontSize: 11, opacity: .8 }}>{c.products.toLocaleString()} products</span>
              </div>
              <div style={{ position: "absolute", left: 18, right: 18, bottom: 18, color: "#fff" }}>
                <div style={{ fontSize: 11, color: "var(--mb-gold-soft)", letterSpacing: ".18em", textTransform: "uppercase" }} className="mb-bn">{c.bn}</div>
                <div className="mb-h-display" style={{ fontSize: 36, lineHeight: 1, marginTop: 4 }}>{c.name}</div>
                <div style={{ fontSize: 13, opacity: .85, marginTop: 8 }}>{c.featured}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, fontSize: 12.5, color: "var(--mb-pink-soft)" }}>
                  Open the world <Icon name="arrow-up-right" size={14} />
                </div>
              </div>
            </div>
          ))}
        </div>
        {/* Smaller secondary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginTop: 14 }}>
          {categories.slice(3).map((c, i) => (
            <div key={i} style={{
              position: "relative",
              borderRadius: "var(--mb-radius)",
              overflow: "hidden",
              aspectRatio: "16 / 9",
              border: "1px solid var(--mb-line)",
              cursor: "pointer",
              background: "#fff",
              display: "flex",
            }}>
              <div className={`mb-img-placeholder ${c.color}`} style={{ width: "45%" }}>
                {c.name.toLowerCase()}
              </div>
              <div style={{ flex: 1, padding: "18px 20px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontSize: 11, color: "var(--mb-pink)", letterSpacing: ".14em", textTransform: "uppercase" }}>0{i+4}</div>
                  <div className="mb-h-display" style={{ fontSize: 26, color: "var(--mb-navy)", marginTop: 4 }}>{c.name}</div>
                  <div style={{ fontSize: 12.5, color: "var(--mb-ink-2)", marginTop: 6 }}>{c.featured}</div>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11.5, color: "var(--mb-ink-3)" }}>
                  <span>{c.products.toLocaleString()} products</span>
                  <Icon name="arrow-right" size={16} color="var(--mb-navy)" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Editor's picks — magazine row */}
      <div style={{ padding: "48px 24px", background: "var(--mb-cream)", marginTop: 36 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 32, alignItems: "center" }}>
          <div>
            <div className="mb-eyebrow">— Editor's note</div>
            <h2 className="mb-h-display" style={{ fontSize: 34, color: "var(--mb-navy)", margin: "8px 0 12px", lineHeight: 1.1 }}>
              "These six landed on every editor's desk this month."
            </h2>
            <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 16 }}>
              <div className="mb-img-placeholder pink" style={{ width: 40, height: 40, borderRadius: 999 }}>RK</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>Rumana K.</div>
                <div style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>Beauty Editor · Dhaka</div>
              </div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
            {[
              { n: "Hydra Glow Serum", b: "Lumière BD", p: "1,490", o: "1,890", badge: "−21%" },
              { n: "Velvet Lip Tint", b: "Noor Studio", p: "850", o: null, badge: "NEW" },
              { n: "Oud Attar 12ml", b: "Aroma House", p: "2,200", o: "2,600", badge: "EDITOR'S" },
            ].map((p, i) => (
              <div key={i} style={{ background: "#fff", borderRadius: "var(--mb-radius)", padding: 14, border: "1px solid var(--mb-line)" }}>
                <div className={`mb-img-placeholder ${["pink","gold","navy"][i]}`} style={{ aspectRatio: "1", borderRadius: 10, marginBottom: 12 }}>
                  product
                </div>
                <div style={{ fontSize: 10, color: "var(--mb-ink-3)", letterSpacing: ".08em", textTransform: "uppercase" }}>{p.b}</div>
                <div style={{ fontSize: 14, fontWeight: 500, marginTop: 2 }}>{p.n}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8 }}>
                  <span style={{ fontSize: 14, fontWeight: 600, color: "var(--mb-pink)" }}>৳{p.p}</span>
                  {p.o && <span style={{ fontSize: 11.5, color: "var(--mb-ink-3)", textDecoration: "line-through" }}>৳{p.o}</span>}
                  <span className="mb-badge mb-badge-pink" style={{ marginLeft: "auto" }}>{p.badge}</span>
                </div>
                <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <StarRating value={4.7} />
                  <span style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>4.7 · 312</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Shop by skin concern — visual */}
      <div style={{ padding: "48px 24px" }}>
        <div className="mb-eyebrow mb-eyebrow-gold">— Skin goals</div>
        <h2 className="mb-h-display" style={{ fontSize: 34, color: "var(--mb-navy)", margin: "6px 0 18px" }}>Tell us your concern. We'll do the rest.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12 }}>
          {[
            ["Acne & Blemish","485","pink"],
            ["Dullness","290","gold"],
            ["Hyperpigmentation","350","pink"],
            ["Sensitivity","220","navy"],
            ["Pores","300","pink"],
            ["Anti-Ageing","410","gold"],
          ].map(([n, c, col], i) => (
            <div key={i} style={{
              borderRadius: "var(--mb-radius)",
              border: "1px solid var(--mb-line)",
              overflow: "hidden",
              cursor: "pointer",
              background: "#fff",
            }}>
              <div className={`mb-img-placeholder ${col}`} style={{ aspectRatio: "1" }}>texture</div>
              <div style={{ padding: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 500, color: "var(--mb-navy)" }}>{n}</div>
                <div style={{ fontSize: 11, color: "var(--mb-ink-3)", marginTop: 2 }}>{c} products</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Brand stories */}
      <div style={{ padding: "0 24px 48px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 18 }}>
          <div>
            <div className="mb-eyebrow">— Behind the bottle</div>
            <h2 className="mb-h-display" style={{ fontSize: 30, color: "var(--mb-navy)", margin: "6px 0 0" }}>Made in Bangladesh, loved everywhere.</h2>
          </div>
          <span style={{ fontSize: 13, color: "var(--mb-pink)" }}>See all 250 brands →</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
          {[
            { b: "Lumière BD", t: "Founded in Sylhet, 2021", p: 84 },
            { b: "Noor Studio", t: "Mother-daughter atelier", p: 52 },
            { b: "Aroma House", t: "Three generations of attar", p: 36 },
            { b: "Tula Botanic", t: "Forest-foraged formulas", p: 28 },
          ].map((x, i) => (
            <div key={i} style={{ borderRadius: "var(--mb-radius)", border: "1px solid var(--mb-line)", overflow: "hidden", background: "#fff" }}>
              <div className={`mb-img-placeholder ${["pink","gold","navy","pink"][i]}`} style={{ aspectRatio: "4/3" }}>founder portrait</div>
              <div style={{ padding: 14 }}>
                <div style={{ fontFamily: "var(--font-display)", fontSize: 18, color: "var(--mb-navy)" }}>{x.b}</div>
                <div style={{ fontSize: 12, color: "var(--mb-ink-3)", marginTop: 2 }}>{x.t}</div>
                <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: "var(--mb-ink-2)" }}>{x.p} products</span>
                  <Icon name="arrow-right" size={14} color="var(--mb-navy)" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <TrustStrip />
      <FooterMini />
    </div>
  );
};

window.DirectionA_Desktop = DirectionA_Desktop;
