/* DIRECTION B — Live Pulse
   Engagement lever: social proof + urgency.
   Live counters, "shopping right now", flash-deal countdowns,
   trending products, review-driven category cards. */

const DirectionB_Desktop = () => {
  return (
    <div className="mb-artboard" style={{ width: "100%", minHeight: "100%" }}>
      <TopBar />

      {/* Live ticker bar */}
      <div style={{
        background: "var(--mb-navy)", color: "#fff",
        padding: "10px 24px", display: "flex", alignItems: "center", gap: 24,
        fontSize: 12.5,
        overflow: "hidden",
      }}>
        <span className="mb-badge mb-badge-live" style={{ background: "rgba(217,83,79,.18)", color: "#FFB4B0" }}>LIVE</span>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Icon name="fire" size={14} color="#D4A248" />
          <strong style={{ color: "#fff" }}>2,847</strong> shoppers browsing right now
        </span>
        <span style={{ opacity: .35 }}>·</span>
        <span><strong style={{ color: "var(--mb-pink-soft)" }}>Asha M.</strong> from Chittagong just bought <em style={{ color: "var(--mb-gold-soft)" }}>Hydra Glow Serum</em></span>
        <span style={{ opacity: .35 }}>·</span>
        <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          <Icon name="clock" size={13} color="#D4A248" />
          Flash deal ends in <strong style={{ color: "#fff" }}>02:14:38</strong>
        </span>
      </div>

      {/* Hero — split: countdown + dynamic categories */}
      <div style={{
        background: "linear-gradient(135deg, var(--mb-navy) 0%, #2a2a4a 100%)",
        color: "#fff",
        padding: "32px 24px",
        position: "relative",
      }}>
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 28 }}>
          <div>
            <span className="mb-badge" style={{ background: "rgba(232,115,158,.2)", color: "var(--mb-pink-soft)" }}>
              ✦ FLASH WEEK · DAY 3 OF 7
            </span>
            <h1 className="mb-h-display" style={{ fontSize: 56, lineHeight: 1.04, margin: "14px 0 14px" }}>
              Up to <span style={{ color: "var(--mb-gold)" }}>50% off</span><br/>
              across all categories.
            </h1>
            <p style={{ fontSize: 15, color: "rgba(255,255,255,.7)", margin: "0 0 22px", maxWidth: 480 }}>
              Verified bestsellers, refreshed every 6 hours. Stock counters live — when they're gone, they're gone.
            </p>
            {/* Countdown */}
            <div style={{ display: "flex", gap: 10 }}>
              {[["02","HOURS"],["14","MIN"],["38","SEC"]].map(([n, l]) => (
                <div key={l} style={{
                  background: "rgba(255,255,255,.08)",
                  border: "1px solid rgba(255,255,255,.12)",
                  borderRadius: 12,
                  padding: "12px 18px",
                  textAlign: "center",
                  minWidth: 78,
                }}>
                  <div className="mb-h-display" style={{ fontSize: 32, color: "var(--mb-gold)" }}>{n}</div>
                  <div style={{ fontSize: 10, letterSpacing: ".15em", opacity: .6 }}>{l}</div>
                </div>
              ))}
              <button className="mb-btn mb-btn-primary" style={{ marginLeft: 6 }}>
                Shop the deals <Icon name="arrow-right" size={14} />
              </button>
            </div>
          </div>
          {/* Right: live trending mini-leaderboard */}
          <div style={{
            background: "rgba(255,255,255,.06)",
            border: "1px solid rgba(255,255,255,.1)",
            borderRadius: "var(--mb-radius)",
            padding: 18,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <span style={{ fontSize: 11, letterSpacing: ".15em", opacity: .7 }}>TRENDING NOW</span>
              <span className="mb-badge mb-badge-live">LIVE</span>
            </div>
            {[
              { r: 1, n: "Niacinamide 10% Serum", b: "Lumière BD", v: "+312%", left: 14 },
              { r: 2, n: "Velvet Matte Lipstick", b: "Noor Studio", v: "+248%", left: 47 },
              { r: 3, n: "Argan Hair Oil 100ml", b: "Shaba Co.", v: "+196%", left: 8 },
              { r: 4, n: "Rose Water Toner", b: "Tula Botanic", v: "+154%", left: 23 },
            ].map(p => (
              <div key={p.r} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: p.r < 4 ? "1px solid rgba(255,255,255,.08)" : "none" }}>
                <span className="mb-h-display" style={{ fontSize: 20, color: "var(--mb-gold)", width: 24 }}>0{p.r}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{p.n}</div>
                  <div style={{ fontSize: 10.5, opacity: .55, textTransform: "uppercase", letterSpacing: ".08em" }}>{p.b}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 12, color: p.left < 15 ? "#FF8B8B" : "var(--mb-pink-soft)" }}>{p.v}</div>
                  <div style={{ fontSize: 10, opacity: .5 }}>{p.left} left</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <TrustStrip />

      {/* Category nav */}
      <div style={{ display: "flex", gap: 6, padding: "14px 24px", borderBottom: "1px solid var(--mb-line)", background: "#fff" }}>
        <span className="mb-chip" data-active="true">All</span>
        <span className="mb-chip">🔥 Trending</span>
        <span className="mb-chip">Skincare</span>
        <span className="mb-chip">Makeup</span>
        <span className="mb-chip">Hair</span>
        <span className="mb-chip">Fragrance</span>
        <span className="mb-chip">Body</span>
        <span className="mb-chip">Wellness</span>
        <span className="mb-chip">Tools</span>
        <span style={{ marginLeft: "auto", fontSize: 13, color: "var(--mb-ink-3)", display: "flex", alignItems: "center", gap: 6 }}>
          <Icon name="filter" size={14} /> Filter
        </span>
      </div>

      {/* Popular Categories — with live signals */}
      <div style={{ padding: "32px 24px 12px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 }}>
          <div>
            <div className="mb-eyebrow">— Popular now</div>
            <h2 className="mb-h-display" style={{ fontSize: 30, color: "var(--mb-navy)", margin: "6px 0 0" }}>What Bangladesh is shopping.</h2>
          </div>
          <span style={{ fontSize: 12, color: "var(--mb-ink-3)" }}>Updated 6 min ago · refreshes every 15 min</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
          {[
            { n: "Sunscreen", a: "SPF", p: 300, trend: "+38%", color: "gold", live: 124 },
            { n: "Serum & Ampoule", a: "SA", p: 633, trend: "+72%", color: "pink", live: 312, hot: true },
            { n: "Lipstick", a: "L", p: 287, trend: "+24%", color: "pink", live: 88 },
            { n: "Perfume", a: "P", p: 196, trend: "+51%", color: "navy", live: 142 },
            { n: "Face Cleanser", a: "C", p: 216, trend: "+12%", color: "gold", live: 67 },
            { n: "Hair Mask", a: "HM", p: 84, trend: "+19%", color: "pink", live: 34 },
            { n: "Body Lotion", a: "BL", p: 158, trend: "+8%", color: "gold", live: 41 },
            { n: "Vitamins", a: "V", p: 72, trend: "+93%", color: "navy", live: 96, hot: true },
          ].map((c, i) => (
            <div key={i} style={{
              background: "#fff",
              border: "1px solid var(--mb-line)",
              borderRadius: "var(--mb-radius)",
              padding: 16,
              cursor: "pointer",
              position: "relative",
            }}>
              {c.hot && (
                <span style={{
                  position: "absolute", top: 12, right: 12,
                  display: "flex", alignItems: "center", gap: 3,
                  fontSize: 10, fontWeight: 700, color: "var(--mb-danger)",
                }}>
                  <Icon name="fire" size={12} color="var(--mb-danger)" /> HOT
                </span>
              )}
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                <div className={`mb-img-placeholder ${c.color}`} style={{ width: 44, height: 44, borderRadius: 999, fontSize: 13, fontWeight: 600 }}>
                  {c.a}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 500, color: "var(--mb-navy)" }}>{c.n}</div>
                  <div style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>{c.p} products</div>
                </div>
              </div>
              {/* Trend bar */}
              <div style={{ height: 4, background: "var(--mb-cream)", borderRadius: 999, overflow: "hidden", marginBottom: 8 }}>
                <div style={{ width: `${Math.min(parseInt(c.trend), 100)}%`, height: "100%", background: "linear-gradient(90deg, var(--mb-pink), var(--mb-gold))" }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
                <span style={{ color: "var(--mb-success)", fontWeight: 600 }}>↑ {c.trend} this week</span>
                <span style={{ color: "var(--mb-ink-3)", display: "flex", alignItems: "center", gap: 4 }}>
                  <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--mb-success)", display: "inline-block" }} />
                  {c.live} viewing
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Flash deals row */}
      <div style={{ padding: "32px 24px", marginTop: 16, background: "linear-gradient(180deg, var(--mb-pink-bg), #fff 70%)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Icon name="fire" size={18} color="var(--mb-pink)" />
              <span className="mb-eyebrow">— Flash deals</span>
            </div>
            <h2 className="mb-h-display" style={{ fontSize: 28, color: "var(--mb-navy)", margin: "4px 0 0" }}>Going fast. Like, really fast.</h2>
          </div>
          <div style={{
            display: "flex", gap: 6, alignItems: "center",
            background: "var(--mb-navy)", color: "#fff",
            padding: "8px 14px", borderRadius: 999,
            fontSize: 12,
          }}>
            <Icon name="clock" size={13} color="var(--mb-gold)" />
            Ends in <strong style={{ color: "var(--mb-gold)" }}>02:14:38</strong>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12 }}>
          {[
            { n: "Niacinamide Serum", b: "Lumière", p: 749, o: 1490, sold: 87, total: 100, color: "pink" },
            { n: "Matte Lipstick", b: "Noor", p: 425, o: 850, sold: 53, total: 100, color: "gold" },
            { n: "Oud Attar 12ml", b: "Aroma", p: 1100, o: 2200, sold: 92, total: 100, color: "navy" },
            { n: "Rose Toner", b: "Tula", p: 590, o: 990, sold: 41, total: 100, color: "pink" },
            { n: "Argan Hair Oil", b: "Shaba", p: 680, o: 1290, sold: 68, total: 100, color: "gold" },
          ].map((p, i) => (
            <div key={i} style={{ background: "#fff", border: "1px solid var(--mb-line)", borderRadius: "var(--mb-radius)", padding: 12 }}>
              <div className={`mb-img-placeholder ${p.color}`} style={{ aspectRatio: "1", borderRadius: 10, marginBottom: 10, position: "relative" }}>
                product
                <span className="mb-badge mb-badge-pink" style={{ position: "absolute", top: 8, left: 8 }}>−{Math.round((1-p.p/p.o)*100)}%</span>
              </div>
              <div style={{ fontSize: 10, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>{p.b}</div>
              <div style={{ fontSize: 13, fontWeight: 500, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.n}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 6 }}>
                <span style={{ fontSize: 15, fontWeight: 700, color: "var(--mb-pink)" }}>৳{p.p}</span>
                <span style={{ fontSize: 11, color: "var(--mb-ink-3)", textDecoration: "line-through" }}>৳{p.o}</span>
              </div>
              {/* Stock bar */}
              <div style={{ marginTop: 10 }}>
                <div style={{ height: 5, background: "var(--mb-cream)", borderRadius: 999, overflow: "hidden" }}>
                  <div style={{
                    width: `${p.sold}%`, height: "100%",
                    background: p.sold > 80 ? "var(--mb-danger)" : "var(--mb-gold)",
                  }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 5, fontSize: 10, color: p.sold > 80 ? "var(--mb-danger)" : "var(--mb-ink-3)", fontWeight: 600 }}>
                  <span>🔥 {p.sold} sold</span>
                  <span>{p.total - p.sold} left</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Skin concern with review counts */}
      <div style={{ padding: "40px 24px" }}>
        <div className="mb-eyebrow mb-eyebrow-gold">— Shop by skin concern</div>
        <h2 className="mb-h-display" style={{ fontSize: 30, color: "var(--mb-navy)", margin: "6px 0 18px" }}>Real concerns. Real reviews.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
          {[
            { n: "Acne & Blemish", p: 485, r: 12400, score: 4.6, top: "Tea Tree Foam" },
            { n: "Hyperpigmentation", p: 350, r: 8200, score: 4.7, top: "Vit C Serum" },
            { n: "Sensitivity", p: 220, r: 5100, score: 4.5, top: "Centella Mist" },
            { n: "Pores & Blackheads", p: 300, r: 9300, score: 4.6, top: "BHA Toner" },
          ].map((c, i) => (
            <div key={i} style={{ background: "#fff", border: "1px solid var(--mb-line)", borderRadius: "var(--mb-radius)", padding: 16 }}>
              <div style={{ fontSize: 14.5, fontWeight: 500, color: "var(--mb-navy)" }}>{c.n}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6 }}>
                <StarRating value={c.score} size={11} />
                <span style={{ fontSize: 11, color: "var(--mb-ink-2)", fontWeight: 600 }}>{c.score}</span>
                <span style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>· {c.r.toLocaleString()} reviews</span>
              </div>
              <div style={{ marginTop: 12, padding: 10, background: "var(--mb-cream)", borderRadius: 8 }}>
                <div style={{ fontSize: 10, color: "var(--mb-ink-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>Most-loved</div>
                <div style={{ fontSize: 12.5, fontWeight: 500, color: "var(--mb-navy)", marginTop: 2 }}>{c.top}</div>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12, fontSize: 11.5, color: "var(--mb-ink-3)" }}>
                <span>{c.p} products</span>
                <span style={{ color: "var(--mb-pink)", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>
                  Browse <Icon name="arrow-right" size={12} />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Customer wall */}
      <div style={{ padding: "0 24px 40px" }}>
        <div className="mb-eyebrow">— Real shoppers</div>
        <h2 className="mb-h-display" style={{ fontSize: 26, color: "var(--mb-navy)", margin: "6px 0 16px" }}>96,000+ reviews and counting.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {[
            { name: "Sadia R.", loc: "Dhaka", q: "The serum literally cleared my forehead in 3 weeks. Glow is unreal.", prod: "Lumière Niacinamide" },
            { name: "Tahmina K.", loc: "Khulna", q: "First lipstick that didn't crack on me by 2pm. Bought 3 more shades.", prod: "Noor Velvet Matte" },
            { name: "Anika H.", loc: "Sylhet", q: "Smells like a Dhaka winter wedding. Lasts all day. Worth every taka.", prod: "Aroma Oud Attar" },
          ].map((r, i) => (
            <div key={i} style={{ background: "var(--mb-cream)", borderRadius: "var(--mb-radius)", padding: 18 }}>
              <StarRating value={5} />
              <div className="mb-h-display" style={{ fontSize: 17, color: "var(--mb-navy)", lineHeight: 1.35, marginTop: 10 }}>"{r.q}"</div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--mb-line)" }}>
                <div>
                  <div style={{ fontSize: 12.5, fontWeight: 600 }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: "var(--mb-ink-3)" }}>{r.loc} · Verified</div>
                </div>
                <div style={{ fontSize: 11, color: "var(--mb-pink)" }}>{r.prod} →</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <FooterMini />
    </div>
  );
};

window.DirectionB_Desktop = DirectionB_Desktop;
